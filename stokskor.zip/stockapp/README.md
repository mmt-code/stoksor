# StokSkor 📊

CH Value benzeri kişisel hisse analiz paneli. Finnhub API kullanır. GitHub Pages üzerinde çalışır — telefon dahil her yerden erişilebilir.

## Özellikler

- **Kalite / Değer / Büyüme / Risk** skorları (ROIC, ROE, P/E, PEG, büyüme oranları…)
- **Hedef fiyat dağılımı** — Bear / Base / Bull (analist konsensüsü)
- **Insider aktivitesi** — Son 90 günün alış/satış işlemleri
- **Kazanç raporları** — EPS sürpriz geçmişi
- **Haber akışı** — Şirkete özel + genel piyasa haberleri
- **Portföy takibi** — Pozisyon ekle, P&L izle, dışa/içe aktar
- **Makro takvim** — Bu haftanın yüksek etkili verileri

## Kurulum

### 1. Finnhub API Key al
[finnhub.io](https://finnhub.io) → Register → API key kopyala (ücretsiz)

### 2. GitHub Pages'e yükle

```bash
# Repo oluştur (GitHub'da "stokskor" adında yeni repo)
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADI/stokskor.git
git push -u origin main
```

GitHub repo → Settings → Pages → Source: `main` branch → Save

Birkaç dakika sonra `https://KULLANICI_ADI.github.io/stokskor` adresinden erişilebilir.

### 3. API key'i gir
Uygulama → Ayarlar → API Anahtarı → Kaydet

API key tarayıcının localStorage'ında saklanır, hiçbir sunucuya gönderilmez.

## Yerel test

Direkt `index.html` dosyasını tarayıcıda açabilirsin — ek kurulum gerekmez.

## Veri kaynakları

| Veri | Kaynak | Tier |
|------|--------|------|
| Fiyat, metrikler, insider | Finnhub | Ücretsiz |
| Hedef fiyat, konsensüs | Finnhub | Ücretsiz |
| Haberler | Finnhub | Ücretsiz |
| Kazanç raporları | Finnhub | Ücretsiz |

## Notlar

- Tüm veriler bilgi amaçlıdır, yatırım tavsiyesi değildir.
- Portföy verisi yalnızca tarayıcında saklanır (localStorage).
- Ücretsiz Finnhub tier'ında dakikada 60 istek limiti vardır.
